
using Microsoft.AspNetCore.Mvc;

namespace ProjetoMVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Sobre()
        {
            return View();
        }
    }
}
